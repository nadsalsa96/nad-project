<?php
include 'config.php';

if (!isset($_GET['id'])) {
    die("ID user tidak ditemukan.");
}

$id = $_GET['id'];

// Ambil data user
$query = "SELECT * FROM user WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    die("User tidak ditemukan.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE user SET email = ?, password = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $email, $hashed_password, $id);
    } else {
        // Kalau password kosong, jangan update password
        $sql = "UPDATE user SET email = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $email, $id);
    }

    if (mysqli_stmt_execute($stmt)) {
        echo "User berhasil diupdate.";
        // Bisa redirect juga:
        // header("Location: read_user.php");
        // exit;
    } else {
        echo "Gagal mengupdate user: " . mysqli_error($conn);
    }
}
?>


<h2>Edit User</h2>
<form method="POST">
    <label>Email:</label><br>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>

    <label>Password (kosongkan jika tidak diubah):</label><br>
    <input type="password" name="password" placeholder="Password baru"><br><br>

    <button type="submit">Update</button>
</form>
