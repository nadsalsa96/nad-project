<?php
// footer.php
?>
    <footer style="background-color: #2c3e50; color: white; padding: 30px 0; text-align: center;">
        <div class="container">
            <h3 style="margin-bottom: 10px;">Food Mood</h3>
            <p style="margin-bottom: 20px;">Makanan untuk setiap perasaan</p>
            <div class="social-links" style="margin-bottom: 15px;">
                <a href="#" style="margin: 0 10px; color: white; text-decoration: none;"><i class="fab fa-instagram"></i></a>
                <a href="#" style="margin: 0 10px; color: white; text-decoration: none;"><i class="fab fa-facebook"></i></a>
                <a href="#" style="margin: 0 10px; color: white; text-decoration: none;"><i class="fab fa-twitter"></i></a>
                <a href="#" style="margin: 0 10px; color: white; text-decoration: none;"><i class="fab fa-tiktok"></i></a>
            </div>
            <p style="font-size: 14px;">&copy; <?= date('Y') ?> Food Mood. All rights reserved.</p>
        </div>
    </footer>
    </div> <!-- .content -->
</body>
</html>
