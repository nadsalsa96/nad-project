<?php
// signup.php
session_start();
require 'config.php';

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $hash     = password_hash($password, PASSWORD_DEFAULT);
    $role     = 'user';

    // Cek dulu email sudah terdaftar
    $check = $conn->prepare("SELECT id FROM user WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        // Kalau duplicate, redirect dengan query error
        header("Location: signup.php?error=duplicate");
        exit;
    } else {
        $stmt = $conn->prepare("INSERT INTO user (email, password, role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $hash, $role);
        if ($stmt->execute()) {
            // Berhasil daftar, langsung ke login dengan flag success
            header("Location: login.php?success=1");
            exit;
        } else {
            header("Location: signup.php?error=insert");
            exit;
        }
    }

    $stmt->close();
    $check->close();
    $conn->close();
}

// Kalau ada GET error, tampilkan pesannya
if (isset($_GET['error'])) {
    if ($_GET['error'] === 'duplicate') {
        $message = "Email sudah terdaftar!";
    } elseif ($_GET['error'] === 'insert') {
        $message = "Registrasi gagal, coba lagi.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - Cheder</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #0a0a23;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .signup-container {
            background-color: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            width: 350px;
            text-align: center;
            color: white;
        }

        .signup-container h2 {
            margin-bottom: 25px;
            color: white;
        }

        .signup-container label {
            display: block;
            text-align: left;
            margin-bottom: 5px;
            font-weight: 500;
            color: white;
        }

        .signup-container input {
            width: 90%;
            padding: 15px;
            margin-bottom: 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 50px;
            outline: none;
           
            font-weight: 600;
            margin-top: 10px;
            box-shadow: 0 4px 15px rgba(255, 96, 0, 0.4);
        }

        .signup-container input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .signup-container input:focus {
            border: 1px solid rgb(161, 161, 161);
            box-shadow: 0 0 5px rgba(140, 162, 183, 0.5);
        }

        .signup-container button {
            width: 100%;
            padding: 15px;
            background-color: #ff6000;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: background 0.1s;
            
        }

        .signup-container button:hover {
            background-color:rgb(193, 194, 195);
        }

        .signup-container .message {
            margin-bottom: 15px;
            font-weight: bold;
        }

        .signup-container .message.error {
            color: red;
        }

        .signup-container .message.success {
            color: lightgreen;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Sign Up</h2>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo (strpos($message, 'berhasil') !== false) ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="email">Email</label>
            <input type="email" name="email" placeholder="Enter your email" required>

            <label for="password">Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
