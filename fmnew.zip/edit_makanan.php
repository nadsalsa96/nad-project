<?php
require_once 'config.php';

// 1. Get food item to edit
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get food data
$stmt = $conn->prepare("SELECT * FROM food WHERE id_food = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$food = $result->fetch_assoc();
$stmt->close();

// Get selected moods for this food
$selectedMoods = [];
$stmt = $conn->prepare("SELECT id_mood FROM mood_food WHERE id_food = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $selectedMoods[] = $row['id_mood'];
}
$stmt->close();

// 2. Get all moods for checkboxes
$moods = [];
$result = $conn->query("SELECT * FROM mood");
while ($row = $result->fetch_assoc()) {
    $moods[] = $row;
}

// 3. Process form submission
if (isset($_POST['update'])) {
    $nama = trim($_POST['nama_makanan']);
    $desc = trim($_POST['deskripsi']);
    $img  = trim($_POST['gambar']);
    $chosenMoods = $_POST['moods'] ?? [];

    try {
        $conn->begin_transaction();

        // Update food data
        $stmt = $conn->prepare("UPDATE food SET nama_makanan=?, deskripsi=?, gambar=? WHERE id_food=?");
        $stmt->bind_param("sssi", $nama, $desc, $img, $id);
        $stmt->execute();
        $stmt->close();

        // Delete existing mood relations
        $stmt = $conn->prepare("DELETE FROM mood_food WHERE id_food=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        // Insert new mood relations
        if (!empty($chosenMoods)) {
            $stmt = $conn->prepare("INSERT INTO mood_food (id_mood, id_food) VALUES (?, ?)");
            foreach ($chosenMoods as $moodId) {
                $stmt->bind_param("ii", $moodId, $id);
                $stmt->execute();
            }
            $stmt->close();
        }

        $conn->commit();
        header("Location: lihat_makanan.php?success=1");
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error updating food: " . $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Makanan</title>
    <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f1f3f6;
      margin: 0;
      padding: 40px;
    }

    .card {
      background-color: #fff;
      max-width: 600px;
      margin: auto;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #333;
    }

    .form-group {
      margin-bottom: 18px;
    }

    label {
      display: block;
      margin-bottom: 6px;
      font-weight: bold;
      color: #444;
    }

    input[type="text"],
    textarea {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 14px;
      box-sizing: border-box;
      transition: 0.3s;
      background-color: #fff;
    }

    input[type="text"]:focus,
    textarea:focus {
      border-color: #007bff;
      box-shadow: 0 0 4px rgba(0, 123, 255, 0.4);
      outline: none;
    }

    textarea {
      min-height: 100px;
      resize: vertical;
    }

    .mood-options {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      margin-top: 8px;
    }

    .mood-options label {
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      font-weight: normal;
    }

    .mood-options input[type="checkbox"] {
      transform: scale(1.2);
      cursor: pointer;
    }

    .submit-btn {
      display: inline-block;
      background-color: #007bff;
      color: white;
      padding: 10px 20px;
      border: none;
      font-size: 15px;
      border-radius: 8px;
      cursor: pointer;
      margin-top: 10px;
      transition: 0.3s;
    }

    .submit-btn:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
    <h1>Edit Makanan</h1>
    
    <?php if (isset($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    
    <?php if ($food): ?>
    <form method="POST">
        <div class="form-group">
            <label>Nama Makanan:</label>
            <input type="text" name="nama_makanan" value="<?= htmlspecialchars($food['nama_makanan']) ?>" required>
        </div>
        
        <div class="form-group">
            <label>Deskripsi:</label>
            <textarea name="deskripsi" required><?= htmlspecialchars($food['deskripsi']) ?></textarea>
        </div>
        
        <div class="form-group">
            <label>URL Gambar:</label>
            <input type="text" name="gambar" value="<?= htmlspecialchars($food['gambar']) ?>" required>
        </div>
        
        <div class="form-group">
            <label>Pilih Mood:</label>
            <div class="checkbox-group">
                <?php foreach ($moods as $m): ?>
                <label>
                    <input type="checkbox" name="moods[]" value="<?= $m['id_mood'] ?>"
                        <?= in_array($m['id_mood'], $selectedMoods) ? 'checked' : '' ?>>
                    <?= htmlspecialchars($m['emoji'] . ' ' . $m['nama_mood']) ?>
                </label><br>
                <?php endforeach; ?>
            </div>
        </div>
        
        <button type="submit" name="update">Update Makanan</button>
        <a href="lihat_makanan.php" style="margin-left: 10px;">Kembali</a>
    </form>
    <?php else: ?>
        <p>Makanan tidak ditemukan. <a href="lihat_makanan.php">Kembali ke daftar</a></p>
    <?php endif; ?>
</body>
</html>