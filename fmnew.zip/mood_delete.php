<?php
require 'config.php';
$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM mood WHERE id_mood = ?");
$stmt->execute([$id]);
header("Location: mood_read.php");
?>
