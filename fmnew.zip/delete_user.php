<?php
// delete_user.php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM user WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "User berhasil dihapus.";
    } else {
        echo "Gagal menghapus user.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "ID user tidak ditemukan.";
}
?>

<a href="read_user.php">Kembali ke daftar user</a>
