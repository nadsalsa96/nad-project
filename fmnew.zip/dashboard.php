<?php
// dashboard.php
require_once 'config.php';
include 'header.php';

// 1. Total Makanan
$totalFood = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM food")
)['total'];

// 2. Total User
$totalUser = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM user")
)['total'];

// 3. Mood Terpopuler
$sql = "
  SELECT m.nama_mood, COUNT(*) AS jumlah
  FROM mood_log ml
  JOIN mood m ON ml.id_mood = m.id_mood
  GROUP BY ml.id_mood
  ORDER BY jumlah DESC
  LIMIT 1
";
$result = mysqli_query($conn, $sql);
$mood_terpopuler = mysqli_fetch_assoc($result);
$moodTerpopulerText = $mood_terpopuler ? $mood_terpopuler['nama_mood'] : 'Belum ada data.';

// 4. Mood Paling Jarang
$sql = "
  SELECT m.nama_mood, COUNT(*) AS jumlah
  FROM mood_log ml
  JOIN mood m ON ml.id_mood = m.id_mood
  GROUP BY ml.id_mood
  ORDER BY jumlah ASC
  LIMIT 1
";
$result = mysqli_query($conn, $sql);
$mood_jarang = mysqli_fetch_assoc($result);
$moodJarangText = $mood_jarang ? $mood_jarang['nama_mood'] : 'Belum ada data.';

/* 5. Makanan Favorit
$sql = "
  SELECT f.nama_makanan, COUNT(*) AS jumlah
  FROM mood_log ml
  JOIN food f ON ml.id_food = f.id_food
  GROUP BY ml.id_food
  ORDER BY jumlah DESC
  LIMIT 1
";
$result = mysqli_query($conn, $sql);
$makanan_favorit = mysqli_fetch_assoc($result);
$makananFavoritText = $makanan_favorit ? $makanan_favorit['nama_makanan'] : 'Belum ada data.';
*/

// 6. Jam Sibuk
$sql = "
  SELECT HOUR(waktu_akses) AS jam, COUNT(*) AS jumlah
  FROM mood_log
  GROUP BY jam
  ORDER BY jumlah DESC
  LIMIT 1
";
$result = mysqli_query($conn, $sql);
$jam_sibuk = mysqli_fetch_assoc($result);
$jamSibukText = $jam_sibuk ? $jam_sibuk['jam'] . ".00 WIB" : 'Belum ada data.';
?>

<html>
    <head>
        <title></title>
        <style>
        * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', sans-serif;
}

body {
    display: flex;
    min-height: 100vh;
    background-color: #ecf0f3;
}

.sidebar {
    width: 240px;
    background-color: #1f2d3d;
    color: white;
    padding: 30px 20px;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar h2 {
    margin-bottom: 40px;
    font-size: 22px;
    text-align: center;
    color: #f39c12;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    margin: 18px 0;
    padding: 12px 16px;
    border-radius: 8px;
    transition: background-color 0.3s ease;
}

.sidebar a:hover,
.sidebar a.active {
    background-color: #34495e;
}

.content {
    flex-grow: 1;
    padding: 40px;
}

.dashboard-title {
    font-size: 28px;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 30px;
}

.row {
    display: flex;
    flex-wrap: wrap;
    gap: 24px;
}

.col {
    flex: 1;
    min-width: 260px;
}

.card {
    background-color: #ffffff;
    padding: 25px 20px;
    border-radius: 16px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    border-left: 6px solid #3498db;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
}

.card h3 {
    font-size: 24px;
    color: #2c3e50;
    margin-bottom: 10px;
}

.card p {
    font-size: 16px;
    color: #7f8c8d;
}

    </style>
    </head>
  <div class="dashboard-title">Selamat Datang, Admin! 👋</div>

  <div class="row">
    <div class="col">
      <div class="card">
        <h3><?= $totalFood ?></h3>
        <p>Total Makanan</p>
      </div>
    </div>

    <div class="col">
      <div class="card">
        <h3><?= $totalUser ?></h3>
        <p>Total User</p>
      </div>
    </div>
  </div>

  <div class="row" style="margin-top: 30px;">
    <div class="col">
      <div class="card">
        <h3>Mood Terpopuler</h3>
        <?php if ($mood_terpopuler): ?>
          <p><?= htmlspecialchars($mood_terpopuler['nama_mood']) ?>
             (<?= $mood_terpopuler['jumlah'] ?> kali)</p>
        <?php else: ?>
          <p>Belum ada data.</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="col">
      <div class="card">
        <h3>Mood Paling Jarang</h3>
        <?php if ($mood_jarang): ?>
          <p><?= htmlspecialchars($mood_jarang['nama_mood']) ?>
             (<?= $mood_jarang['jumlah'] ?> kali)</p>
        <?php else: ?>
          <p>Belum ada data.</p>
        <?php endif; ?>
      </div>
    </div>


    <div class="col">
      <div class="card">
        <h3>Jam Sibuk</h3>
        <?php if ($jam_sibuk): ?>
          <p><?= $jam_sibuk['jam'] ?>.00 – <?= $jam_sibuk['jam'] + 1 ?>.00 WIB
             (<?= $jam_sibuk['jumlah'] ?> kali)</p>
        <?php else: ?>
          <p>Belum ada data.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>








