<?php
session_start();
require 'config.php';

if (!isset($_SESSION['id_user'])) {
  http_response_code(401);
  echo 'not_login';
  exit;
}

$id_user = (int) $_SESSION['id_user'];
$id_mood = isset($_POST['id_mood']) ? (int) $_POST['id_mood'] : 0;
$id_food = isset($_POST['id_food']) ? (int) $_POST['id_food'] : 0;

if ($id_mood <= 0 || $id_food <= 0) {
  echo 'invalid_params';
  exit;
}

// Simpan ke mood_log
$stmt = mysqli_prepare($conn, "
    INSERT INTO mood_log (id_user, id_mood, id_food, waktu_akses)
    VALUES (?, ?, ?, NOW())
");
mysqli_stmt_bind_param($stmt, "iii", $id_user, $id_mood, $id_food);
$ok = mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

echo $ok ? 'success' : 'error';
?>


<style>
.saved-container {
  max-width: 800px;
  margin: 2rem auto;
  padding: 1rem;
}

.food-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 1.5rem;
  margin: 2rem 0;
}

.food-card {
  background: white;
  border-radius: 10px;
  padding: 1rem;
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: transform 0.3s;
}

.food-card:hover {
  transform: translateY(-5px);
}

.mood-badge {
  display: inline-block;
  background: #FFEEEE;
  color: #FF4B2B;
  padding: 0.2rem 0.5rem;
  border-radius: 20px;
  font-size: 0.8rem;
  margin: 0.5rem 0;
}

.remove-btn {
  background: none;
  border: none;
  color: #FF4B2B;
  cursor: pointer;
  font-size: 1.2rem;
  padding: 0.5rem;
}

.clear-btn {
  background: #FF4B2B;
  color: white;
  border: none;
  padding: 0.8rem 1.5rem;
  border-radius: 5px;
  cursor: pointer;
  display: block;
  margin: 2rem auto 0;
}

.empty-state {
  text-align: center;
  grid-column: 1 / -1;
  padding: 2rem;
}

.empty-state img {
  max-width: 200px;
  opacity: 0.7;
  margin-bottom: 1rem;
}
</style>

<script>
//query insert
// Ambil id user dari session login (misal)
$id_user = $_SESSION['id_user']; // pastikan session diset saat login

// Ambil id_mood dan id_food dari input/form
$id_mood = $_POST['id_mood'];   // atau dari GET, tergantung alur kamu
$id_food = $rekomendasi_id;     // hasil dari sistem rekomendasi

// Simpan ke mood_log
mysqli_query($conn, "INSERT INTO mood_log (id_user, id_mood, id_food, waktu_akses)
         VALUES ('$id_user', '$id_mood', '$id_food', NOW()));
</script>
