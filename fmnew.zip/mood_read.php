<?php
require 'config.php';
include 'header.php';

$sql = "SELECT * FROM mood";
$result = mysqli_query($conn, $sql);

$moods = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $moods[] = $row;
    }
}
?>

<html>
    <head>
        <title></title>
        <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            background-color: #f5f7fa;
        }

        .sidebar {
            width: 220px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 30px;
            font-size: 20px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            margin: 15px 0;
            padding: 10px;
            border-radius: 5px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #34495e;
        }

        .content {
            flex-grow: 1;
            padding: 30px;
        }

        .card {
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .card h3 {
            font-size: 28px;
            color: #2c3e50;
        }

        .card p {
            font-size: 16px;
            color: #7f8c8d;
        }

        .dashboard-title {
            margin-bottom: 20px;
            font-size: 26px;
            font-weight: bold;
            color: #2c3e50;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .col {
            flex: 1;
            min-width: 250px;
        }
        table {
      border-collapse: collapse;
      width: 100%;
      background-color: white;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      border-radius: 8px;
      overflow: hidden;
    }

    th, td {
      padding:  10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #343a40;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .btn {
      display: inline-block;
      padding: 6px 12px;
      margin-right: 5px;
      background-color: #007bff;
      color: white;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
      transition: background-color 0.3s;
    }

    .btn:hover {
      background-color: #0056b3;
    }

    .btn.delete {
      background-color: #dc3545;
    }

    .btn.delete:hover {
      background-color: #c82333;
    }

    * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', sans-serif;
}

body {
    display: flex;
    min-height: 100vh;
    background-color: #ecf0f3;
}

.sidebar {
    width: 240px;
    background-color: #1f2d3d;
    color: white;
    padding: 30px 20px;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar h2 {
    margin-bottom: 40px;
    font-size: 22px;
    text-align: center;
    color: #f39c12;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    margin: 18px 0;
    padding: 12px 16px;
    border-radius: 8px;
    transition: background-color 0.3s ease;
}

.sidebar a:hover,
.sidebar a.active {
    background-color: #34495e;
}

.content {
    flex-grow: 1;
    padding: 40px;
}

.dashboard-title {
    font-size: 28px;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 30px;
}

.row {
    display: flex;
    flex-wrap: wrap;
    gap: 24px;
}

.col {
    flex: 1;
    min-width: 260px;
}

.card {
    background-color: #ffffff;
    padding: 25px 20px;
    border-radius: 16px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    border-left: 6px solid #3498db;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
}

.card h3 {
    font-size: 24px;
    color: #2c3e50;
    margin-bottom: 10px;
}

.card p {
    font-size: 16px;
    color: #7f8c8d;
}

    </style>
    </head>
<h2>Daftar Mood</h2>
<a href="mood_create.php">+ Tambah Mood</a>
<table border="1">
    <tr>
        <th>Emoji</th>
        <th>Nama</th>
        <th>Deskripsi</th>
        <th>Warna</th>
        <th>Kata Kunci</th>
        <th>Aksi</th>
    </tr>
    <?php foreach ($moods as $m): ?>
    <tr>
        <td><?= $m['emoji'] ?></td>
        <td><?= $m['nama_mood'] ?></td>
        <td><?= $m['deskripsi'] ?></td>
        <td><?= $m['warna'] ?></td>
        <td><?= $m['kata_kunci'] ?></td>
        <td>
            <a class="btn" href="mood_update.php?id=<?= $m['id_mood'] ?>">Edit</a>
            <a class="btn delete" href="mood_delete.php?id=<?= $m['id_mood'] ?>"
                  onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
