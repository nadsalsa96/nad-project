<?php
// header.php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>FoodMood Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { box-sizing:border-box; margin:0; padding:0; font-family:'Segoe UI',sans-serif; }
    body { display:flex; min-height:100vh; background:#f5f7fa; }
    .sidebar {
      width:220px; background:#2c3e50; color:#fff; padding:20px;
    }
    .sidebar h2 {
      text-align:center; margin-bottom:30px; font-size:20px;
    }
    .sidebar a {
      display:block; color:#fff; text-decoration:none;
      margin:12px 0; padding:10px; border-radius:4px;
      transition:background 0.2s;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background:#34495e;
    }
    .content {
      flex:1; padding:30px;
    }
    .row { display:flex; flex-wrap:wrap; gap:20px; }
    .col { flex:1; min-width:250px; }
    .card {
      background:#fff; padding:25px; border-radius:10px;
      box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }
    .card h3 { font-size:28px; color:#2c3e50; }
    .card p  { font-size:16px; color:#7f8c8d; }
    .dashboard-title {
      margin-bottom:20px; font-size:26px;
      font-weight:bold; color:#2c3e50;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h2>🍽 FoodMood Admin</h2>
    <a href="dashboard.php"      class="<?= $current==='dashboard.php'     ? 'active':'' ?>">Dashboard</a>
    <a href="lihat_makanan.php"  class="<?= $current==='lihat_makanan.php' ? 'active':'' ?>">Data Makanan</a>
    <a href="read_user.php"      class="<?= $current==='read_user.php'     ? 'active':'' ?>">Data User</a>
    <a href="mood_read.php"      class="<?= $current==='mood_read.php'     ? 'active':'' ?>">Data Mood</a>
    <a href="logout.php">Logout</a>
  </div>
  <div class="content">
