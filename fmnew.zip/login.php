<?php
// login.php
session_start();
require 'config.php';

$message = "";

// Tangkap pesan dari signup (jika ada)
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $message = "Registrasi berhasil! Silakan login";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, email, password, role FROM user WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $u = $result->fetch_assoc();
        if (password_verify($password, $u['password'])) {
            $_SESSION['id'] = $u['id'];
            $_SESSION['email']   = $u['email'];
            $_SESSION['role']    = $u['role'];

            if ($u['role'] === 'admin') {
                header("Location: dashboard.php");
            } else {
                header("Location: rek.php");
            }
            exit;
        } else {
            $messagee = "Password salah!";
        }
    } else {
        $messagee = "Email tidak ditemukan!";
    }
    $stmt->close();
    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - Cheder</title>
  <style>
    :root {
        --primary: #0a0a23;
        --secondary: #ff6000;
        --accent: #ff8c42;
        --light: #f8f9fa;
        --dark: #212529;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, var(--primary), #1a0b73);
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        position: relative;
        overflow: hidden;
    }

    .bubble {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(5px);
        animation: float 15s infinite linear;
        z-index: 0;
    }

    @keyframes float {
        0% { transform: translateY(0) rotate(0deg); }
        100% { transform: translateY(-1000px) rotate(720deg); }
    }

    .logo {
        position: absolute;
        top: 30px;
        left: 30px;
        width: 100px;
        height: auto;
        filter: drop-shadow(0 2px 5px rgba(0,0,0,0.2));
        transition: transform 0.3s ease;
        z-index: 10;
    }

    .logo:hover {
        transform: scale(1.05);
    }

    .login-container {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 40px;
        width: 100%;
        max-width: 450px;
        box-shadow: 0 25px 45px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.1);
        position: relative;
        overflow: hidden;
        z-index: 1;
        animation: fadeIn 0.8s ease-out;
    }

    .login-container::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: linear-gradient(
            to bottom right,
            rgba(255, 255, 255, 0.05) 0%,
            rgba(255, 255, 255, 0) 50%,
            rgba(255, 96, 0, 0.05) 100%
        );
        transform: rotate(30deg);
        z-index: -1;
        animation: shine 8s infinite;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes shine {
        0% { transform: rotate(30deg) translate(-30%, -30%); }
        100% { transform: rotate(30deg) translate(30%, 30%); }
    }

    .login-box {
        display: flex;
        flex-direction: column;
        gap: 25px;
    }

    .login-box span {
        font-size: 2.2rem;
        font-weight: 700;
        color: white;
        margin-bottom: 5px;
        text-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }

    .login-box p {
        color: rgba(255, 255, 255, 0.8);
        font-size: 0.9rem;
        position: relative;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .login-box p::before,
    .login-box p::after {
        content: '';
        flex: 1;
        height: 1px;
        background: rgba(255, 255, 255, 0.3);
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .input-group {
        position: relative;
    }

    .input-group label {
        position: absolute;
        top: -10px;
        left: 15px;
        background: var(--primary);
        padding: 0 8px;
        font-size: 0.8rem;
        color: white;
        border-radius: 10px;
        z-index: 1;
    }

    .input-group input {
        width: 100%;
        padding: 15px 20px;
        border-radius: 50px;
        border: 2px solid rgba(255, 255, 255, 0.2);
        background: rgba(255, 255, 255, 0.1);
        color: white;
        font-size: 1rem;
        transition: all 0.3s ease;
    }

    .input-group input::placeholder {
        color: rgba(255, 255, 255, 0.5);
    }

    .input-group input:focus {
        outline: none;
        border-color: var(--secondary);
        background: rgba(255, 255, 255, 0.15);
        box-shadow: 0 0 0 3px rgba(255, 96, 0, 0.2);
    }

    .sign-in-btn {
        background: var(--secondary);
        color: rgb(254, 254, 254);
        border: none;
        padding: 15px;
        border-radius: 50px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-top: 10px;
        box-shadow: 0 4px 15px rgba(255, 96, 0, 0.4);
    }

    .sign-in-btn:hover {
        background: var(--accent);
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(255, 96, 0, 0.5);
    }

    .signup-link {
        text-align: center;
        color: rgba(255, 255, 255, 0.7);
        font-size: 0.9rem;
    }

    .signup-link a {
        color: white;
        font-weight: 500;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .signup-link a:hover {
        color: var(--secondary);
        text-decoration: underline;
    }

    @media (max-width: 480px) {
        .login-container {
            padding: 30px;
            margin: 0 20px;
        }
        .logo {
            width: 80px;
            top: 20px;
            left: 20px;
        }
    }
  </style>
</head>
<body>

  <img src="cheder.png" alt="Logo" class="logo">

  <div class="login-container">
    <div class="login-box">
      <span>Sign In</span>


      <?php if (!empty($message)): ?>
          <p style="color: green;"><?php echo $message; ?></p>
      <?php endif; ?>

      <?php if (!empty($messagee)): ?>
          <p style="color: red;"><?php echo $messagee; ?></p>
      <?php endif; ?>

      <form id="login-form" action="login.php" method="POST">
        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" placeholder="hello@gmail.com" required>
        </div>

        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" placeholder="••••••••" required>
        </div>

        <button type="submit" class="sign-in-btn" id="login-btn">Sign In</button>
      </form>

      <p class="signup-link">Don't have an account? <a href="signup.php">Sign up</a></p>
    </div>
  </div>

</body>
</html>
