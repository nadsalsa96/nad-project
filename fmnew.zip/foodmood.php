<?php
// Misalnya, kita bisa memulai session atau memuat data dinamis seperti nama situs atau pengguna yang login
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Mood Matcher - Find Food Based on Your Mood</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
      /* ===== BASE STYLES ===== */
html {
    scroll-behavior: smooth;
}

:root {
    --primary: #0a0a23;
    --secondary: #fd0a0a;
    --accent: #ff5e00;
    --text-light: #ffffff;
    --text-dark: #000000;
    --bg-hover: rgba(239, 236, 236, 0.7);
}

body {
    background-color: var(--primary);
    color: var(--text-light);
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    overflow-x: hidden;
}

/* ===== CUSTOM CURSOR ===== */
.custom-cursor {
    position: fixed;
    width: 20px;
    height: 20px;
    background-color: rgba(255, 0, 0, 0.7);
    border-radius: 50%;
    pointer-events: none;
    transform: translate(-50%, -50%);
    transition: transform 0.1s ease-out;
    z-index: 9999;
    mix-blend-mode: difference;
}

/* === NAVIGASI === */
nav {
    background-color: rgba(0, 0, 0, 0.3); /* More visible semi-transparent */
    padding: 12px 0;
    position: sticky;
    top: 0;
    z-index: 100;
    backdrop-filter: blur(8px); /* Frosted glass effect */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.nav-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 30px;
}

.logo {
    height: 52px; /* Slightly larger */
    width: auto;
    transition: transform 0.3s ease;
}

.logo:hover {
    transform: scale(1.05); /* Subtle hover effect */
}

.navbar {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
    gap: 20px;
}

.navbar li {
    position: relative;
    display: flex;
    align-items: center;
}

/* Main nav items */
.navbar > li > a {
    color: white;
    text-decoration: none;
    font-weight: 600;
    font-size: 16px;
    padding: 8px 15px;
    border-radius: 20px;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}

/* Hover effect for main nav items */
.navbar > li > a:not(.login-btn):hover {
    color: #fff;
    background-color: rgba(253, 10, 10, 0.2);
    transform: translateY(-2px);
}

/* Underline animation */
.navbar > li > a:not(.login-btn)::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 2px;
    background: #fd0a0a;
    transition: all 0.3s ease;
    transform: translateX(-50%);
}

.navbar > li > a:not(.login-btn):hover::after {
    width: 60%;
}

/* Active state */
.navbar a.active {
    background-color: var(--secondary);
    color: var(--text-light);
    box-shadow: 0 4px 8px rgba(253, 10, 10, 0.3);
}

/* Dropdown menu */
.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%) translateY(10px);
    background: white;
    border-radius: 8px;
    padding: 8px 0;
    min-width: 180px;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    z-index: 10;
}

.dropdown:hover .dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateX(-50%) translateY(0);
}

.dropdown-menu li {
    padding: 8px 20px;
    transition: background-color 0.2s;
}

.dropdown-menu li:hover {
    background-color: #f8f8f8;
}

.dropdown-menu a {
    color: var(--text-dark);
    font-size: 14px;
    white-space: nowrap;
    display: block;
}

/* Login button */
.login-btn {
    background-color: #fd0a0a;
    color: white !important;
    padding: 8px 22px !important;
    border-radius: 20px;
    margin-left: 10px;
    transition: all 0.3s ease;
    font-weight: 600;
}

.login-btn:hover {
    background-color: #ff2e00;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(253, 10, 10, 0.3);
}

/* Mobile menu toggle (optional) */
.mobile-menu-toggle {
    display: none;
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
}

/* ===== HERO SECTION ===== */
.hero {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 5% 10%;
    position: relative;
    min-height: 80vh;
}

.hero-text {
    max-width: 500px;
    z-index: 2;
}

.subheading {
    font-size: 1.1rem;
    opacity: 0.8;
    margin-bottom: 10px;
    text-transform: uppercase;
    letter-spacing: 2px;
}

.main-title {
    font-size: 3.5rem;
    font-weight: 800;
    line-height: 1.2;
    margin: 20px 0;
    text-shadow: 2px 2px 5px rgba(0,0,0,0.3);
}

.highlight {
    color: var(--accent);
    position: relative;
}

.highlight::after {
    content: '';
    position: absolute;
    bottom: 5px;
    left: 0;
    width: 100%;
    height: 8px;
    background-color: rgba(255, 94, 0, 0.3);
    z-index: -1;
    border-radius: 10px;
}

.search-container {
    margin-top: 30px;
}

.search-bar {
    display: flex;
    align-items: center;
    max-width: 400px;
    background: white;
    border-radius: 30px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.search-bar input {
    padding: 12px 20px;
    border: none;
    width: 100%;
    outline: none;
    font-family: 'Poppins', sans-serif;
}

.search-btn {
    background: var(--secondary);
    border: none;
    padding: 12px 20px;
    color: white;
    cursor: pointer;
    transition: background 0.3s;
}

.search-btn:hover {
    background: var(--accent);
}

.quick-moods {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 15px;
    flex-wrap: wrap;
}

.quick-moods span {
    font-size: 0.9rem;
    opacity: 0.8;
}

.mood-tag {
    background: transparent;
    border: 1px solid var(--accent);
    color: var(--accent);
    padding: 5px 15px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    gap: 5px;
}

.mood-tag:hover {
    background: var(--accent);
    color: white;
}

/* Hero image section */
.hero-image {
    position: relative;
    width: 50%;
    min-width: 350px;
}

.background-shape {
    position: absolute;
    top: -50px;
    right: -50px;
    width: 105%;
    z-index: 1;
    opacity: 0.8;
    animation: float 6s ease-in-out infinite;
}

.illustration {
    position: relative;
    width: 100%;
    max-width: 500px;
    z-index: 2;
    animation: float 4s ease-in-out infinite;
    animation-delay: 0.5s;
}

/* ===== ANIMATIONS ===== */
@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-15px); }
    100% { transform: translateY(0px); }
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ===== MOBILE RESPONSIVENESS ===== */
@media (max-width: 768px) {
    .hero {
        flex-direction: column;
        text-align: center;
        padding: 20px;
    }
    
    .hero-text {
        margin-bottom: 40px;
    }
    
    .search-bar {
        margin: 0 auto;
    }
    
    .quick-moods {
        justify-content: center;
    }
    
    .hero-image {
        min-width: 300px;
    }
    
    .background-shape {
        right: -30px;
    }
}

/* === RESULTS SECTION === */
.results-section {
    padding: 50px 10%;
    background: #1a1a6b;
}

.food-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 30px;
    margin-top: 30px;
}

.food-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    color: #0C0C50;
    transition: transform 0.3s;
}

.food-card:hover {
    transform: translateY(-10px);
}

.food-card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
}

.food-card h3 {
    padding: 15px 20px 0;
    margin: 0;
}

.food-card p {
    padding: 0 20px 15px;
    opacity: 0.8;
}

.order-btn {
    display: block;
    background: #fd0a0a;
    color: white;
    text-align: center;
    padding: 10px;
    text-decoration: none;
    font-weight: bold;
}

/* Loading Animation */
.api-loading {
    text-align: center;
    padding: 30px;
  }
  
  .spinner {
    border: 5px solid rgba(255,255,255,0.3);
    border-radius: 50%;
    border-top: 5px solid #fd0a0a;
    width: 50px;
    height: 50px;
    animation: spin 1s linear infinite;
    margin: 0 auto 15px;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }

/* footer */
  .footer {
  background-color:rgb(1, 0, 22);
  color: #ffffff;
  padding: 50px 20px 30px;
  font-family: 'Poppins', sans-serif;
}

.footer-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 40px;
  max-width: 1200px;
  margin: 0 auto;
}

.footer-column {
  flex: 1 1 200px;
}

.footer-column h4 {
  font-size: 18px;
  margin-bottom: 15px;
  color: #ffffff;
}

.footer-column ul {
  list-style: none;
  padding: 0;
}

.footer-column ul li {
  margin-bottom: 10px;
}

.footer-column ul li a {
  color: #cccccc;
  text-decoration: none;
  transition: color 0.3s ease;
}

.footer-column ul li a:hover {
  color: #ff5f5f;
}

.social-icons a {
  margin-right: 15px;
  font-size: 20px;
  color: #cccccc;
  transition: color 0.3s ease;
}

.social-icons a:hover {
  color: #ff5f5f;
}

.footer-bottom {
  text-align: center;
  margin-top: 40px;
  font-size: 14px;
  color: #aaaaaa;
  border-top: 1px solid #222;
  padding-top: 15px;
}


/* Animasi fade-in */
.hidden {
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.6s ease, transform 0.6s ease;
}

.show {
    opacity: 1;
    transform: translateY(0);
}

.container h2 {
    color: #ffffff;
    font-family: 'Gloria Hallelujah', cursive;
    margin-top: 80px;
    padding: 10px;
    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5); /* Efek bayangan biar lebih jelas */
    font-size: 18px;
}

/* about */
.about-section {
    background-color: #0a0a23; /* warna gelap agar konsisten dengan tema */
    color: #ffffff;
    padding: 110px 20px;
    text-align: center;
  }
  
  .about-container {
    max-width: 800px;
    margin: 0 auto;
    font-family: 'Gloria Hallelujah', cursive;
  }
  
  .about-section h2 {
    font-size: 50px;
    margin-bottom: 10px;
    color: #ff6a00; /* warna judul bisa disesuaikan */
  }
  
  .about-section p {
    font-size: 18px;
    line-height: 1.7;
    margin-bottom: 15px;
  }

/* contact */
.contact-header {
  text-align: center;
  margin-bottom: 20px;
}

.contact-title {
  font-size: 2.8rem;
  color: #ff4b2b;
  margin-bottom: 15px;
  position: relative;
  display: inline-block;
}

.contact-title::after {
  content: '';
  position: absolute;
  width: 80px;
  height: 4px;
  bottom: -15px;
  left: 50%;
  transform: translateX(-50%);
  border-radius: 2px;
}

.contact-subtitle {
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.8);
  max-width: 600px;
  margin: 0 auto;
  line-height: 1.6;
}
.contact-cards {
  display: flex;
  gap: 30px;
  flex-wrap: wrap;
  justify-content: center;
}

.contact-card {
  background-color: #1e1e2f;
  color: white;
  padding: 30px 25px;
  border-radius: 12px;
  width: 280px;
  text-align: center;
  transition: all 0.4s ease;
  border: 1px solid rgba(255, 75, 43, 0.1);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.contact-card:hover {
  transform: translateY(-10px) scale(1.03);
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
  border-color: rgba(255, 75, 43, 0.3);
}

.contact-card i {
  font-size: 32px;
  margin-bottom: 15px;
  color: #ff4b2b;
  transition: transform 0.3s;
}

.contact-card:hover .contact-icon {
  transform: scale(1.2);
}

.contact-card h3 {
  font-size: 1.4rem;
  margin-bottom: 15px;
  color: white;
}

.contact-card p {
  color: rgba(255, 255, 255, 0.7);
  line-height: 1.6;
  margin-bottom: 0;
}

.contact-link {
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  transition: color 0.3s;
}

.contact-link:hover {
  color: #ff4b2b;
  text-decoration: none;
}

.contact-section {
  font-family: 'Gloria Hallelujah', cursive;
  scroll-margin-top: 80px; /* Sesuaikan dengan tinggi navbar */
  padding-top: 30px;
  min-height: 80vh;
}

.contact-section::before {
  content: "";
  display: block;
  height: 100px; /* Tinggi navbar */
  margin-top: -100px; /* Negatif dari height */
  visibility: hidden;
}

/* Responsive Design */
@media (max-width: 768px) {
  .contact-section {
    padding: 60px 15px;
  }
  
  .contact-title {
    font-size: 2.2rem;
  }
  
  .contact-subtitle {
    font-size: 1rem;
  }

}
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="nav-container">
          <a href="http://localhost/fmnew/rek.php">
            <img src="cheder.png" alt="Logo" class="logo">
          </a>
            
            <ul class="navbar">
                <li><a href="#">Home</a></li>
                <li><a href="#About">About Us</a></li>
                <li><a href="#contact">Contact</a></li>
                <?php if (isset($_SESSION['user_logged_in'])): ?>
                    <li><a href="logout.php" class="login-btn">Logout</a></li>
                <?php else: ?>
                    <li><a href="http://localhost/fmnew/login.php" class="login-btn">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    
    <!-- Hero Section -->
    <section class="hero">
    <div class="hero-text">
        <p class="subheading">Get rid of your confusion</p>
        <h1 class="main-title">Serving <span class="highlight">mood</span><br>on a <span class="highlight">Plate</span></h1>
    </div> 
    
    <div class="hero-image">
        <img src="elip.png" alt="Decorative background" class="background-shape">
        <img src="logo.png" alt="Food illustration" class="illustration">
    </div>
</section>

    
<!-- Bagian About -->
<section id="About" class="about-section">
    <div class="about-container">
      <h2>About Us</h2>
      <p>
        Welcome to <strong>Cheder!</strong> — Tempat buat nyari makanan yang relate banget sama mood lo. Lagi seneng? Sedih? BT? Lelah akut? Di sini lo bakal nemu makanan yang vibes-nya cocok banget sama perasaan lo.
      </p>
      <p>
        Kita bikin Cheder karena percaya: makanan tuh bukan cuma soal kenyang, tapi soal hati juga. Bareng teknologi mood-detector dan algoritma kece, kita siap bantu lo cari makanan yang bisa nyelametin hari lo.
      </p>
      <p>
        Gaskeun cari makanan yang match banget sama mood lo sekarang. Let’s vibe & eat, bestie! 😋🍔💖
      </p>
    </div>
</section>
  
<!-- Contact-->
<section id="contact" class="contact-section">
  <div class="contact-container">
    <center>
    <div class="contact-header">
      <h2 class="contact-title">Contact Us</h2>
      <p class="contact-subtitle">Kami senang mendengar feedback, pertanyaan, atau ide makanan darimu!</p>
    </div>
    </center>

    <div class="contact-cards">
      <div class="contact-card">
        <i class="fas fa-envelope"></i>
        <h3>Email</h3>
        <p><a href="mailto:foodmood967@gmail.com">foodmood@gmail.com</a></p>
      </div>

      <div class="contact-card">
        <i class="fab fa-whatsapp"></i>
        <h3>WhatsApp</h3>
        <p><a href="https://wa.me/6285366016654" target="_blank">+62 853 6601 6654</a></p>
      </div>

      <div class="contact-card">
        <i class="fas fa-comment-dots"></i>
        <h3>Send a Message</h3>
        <p><a href="https://forms.gle/1QMhrpsJK9VsbFhG7">Kirim pesan langsung ke kami</a></p>
      </div>
    </div>
  </div>
</section>

    
    <!--FOOTER-->
    <footer class="footer">
        <div class="footer-container">
          <div class="footer-column">
            <h4>Company</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#About">About us</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>
          
          <div class="footer-column">
            <h4>Connect with Us</h4>
            <div class="social-icons">
              <a href="https://www.instagram.com/nadiaslsbila._" target="_blank"><i class="fab fa-instagram"></i></a>
              <a href="https://twitter.com/NAD1SALSA" target="_blank"><i class="fab fa-twitter"></i></a>
              <a href="https://github.com/nadsalsa96" target="_blank"><i class="fa-brands fa-github"></i></a>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2025 Food Mood Match. All rights reserved.</p>
        </div>
        
      </footer>

</body>
</html>