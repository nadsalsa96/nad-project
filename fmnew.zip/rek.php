<?php
// rekomendasi.php

session_start();
require 'config.php';


// FUNGSI UTAMA
function getMoods($conn) {
    $result = mysqli_query($conn, "SELECT * FROM mood");
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    return $data;
}

function searchFoodByMood($conn, $inputMood) {
    $result = mysqli_query($conn, "SELECT * FROM mood");
    $moods = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $moods[] = $row;
    }

    $foundMoodId = null;
    foreach ($moods as $mood) {
        $keywords = explode(',', strtolower($mood['kata_kunci']));
        if (in_array(strtolower($inputMood), array_map('trim', $keywords))) {
            $foundMoodId = $mood['id_mood'];
            break;
        }
    }

    if ($foundMoodId === null) return [];

    $stmt = mysqli_prepare($conn, "
        SELECT m.* FROM food m
        JOIN mood_food mm ON m.id_food = mm.id_food
        WHERE mm.id_mood = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $foundMoodId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $foods = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $foods[] = $row;
    }
    mysqli_stmt_close($stmt);
    return $foods;
}


// PROSES INPUT USER
$mood = '';
$foodResults = [];
$moodData = null;

if (isset($_GET['mood'])) {
    $mood = strtolower(trim($_GET['mood']));
    $foodResults = searchFoodByMood($conn, $mood);

    $stmt = mysqli_prepare($conn, "SELECT * FROM mood WHERE nama_mood = ?");
    mysqli_stmt_bind_param($stmt, "s", $mood);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $moodData = mysqli_fetch_assoc($result);
    
    // ——— Mulai Logging Mood Otomatis ———
if (isset($_SESSION['id']) && $moodData) {
    $id_user  = (int) $_SESSION['id'];
    $id_mood  = (int) $moodData['id_mood'];
    // NOTE: kita biarkan id_food NULL, hanya log mood + waktu
    $stmt2 = mysqli_prepare($conn, "
      INSERT INTO mood_log (id_user, id_mood, id_food, waktu_akses)
      VALUES (?, ?, NULL, NOW())
    ");
    mysqli_stmt_bind_param($stmt2, "ii", $id_user, $id_mood);
    mysqli_stmt_execute($stmt2);
    mysqli_stmt_close($stmt2);
}
// ——— Selesai Logging ———

    mysqli_stmt_close($stmt);
}
$allMoods = getMoods($conn);
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
  />
  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap"
    rel="stylesheet"
  />
  <title>Food Mood - Makanan Sesuai Perasaanmu</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #0a0a23;
      color: #f0f0f0;
      margin: 0;
      padding: 0;
    }
    body, h1, h2, p, button, input {
  transition: all 0.3s ease;
    }
 header {
  background: url('up.jpeg') center/cover no-repeat;
  color: white;
  padding: 50px 0;
  text-align: center;
  box-shadow: inset 0 0 0 1000px rgba(10, 10, 35, 0.8);
}

    header h1 {
      font-size: 3em;
      margin-bottom: 10px;
    }
    header p {
      font-size: 1.2em;
      font-weight: 300;
    }
    .container {
      max-width: 1200px;
      margin: auto;
      padding: 20px;
    }
   .search-box {
      display: flex;
      margin: 40px 0;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      border-radius: 50px;
      overflow: hidden;
      max-width: 800px;
      margin-left: auto;
      margin-right: auto;
    }
    .search-box input {
      flex: 1;
      padding: 15px;
      border: none;
      border-radius: 10px 0 0 10px;
      font-size: 16px;
      outline: none;
      background: #2a2f40;
      color: #f0f0f0;
    }
    .search-box button {
      padding: 15px 25px;
      background: #fd0a0a;
      color: white;
      border: none;
      border-radius: 0 10px 10px 0;
      cursor: pointer;
      font-size: 16px;
      transition: background 0.3s ease;
    }
    .search-box button:hover {
      background: #ff9f43;
    }
    .mood-tags {
      justify-content: center;
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      margin: 40px 0;
    }
    .mood-tag {
      padding: 12px 25px;   
      background: var(--primary);
      color: white;
      border: none;
      border-radius: 50px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.3s ease;
      font-family: 'Gloria Hallelujah', cursive;
      font-size: 16px;
      box-shadow: 0 4px 15px rgba(224, 1, 1, 0.96);
    }
.mood-tag:hover {
  background: linear-gradient(45deg,rgb(229, 20, 20),  #fd0a0a, #fd0a0a);
  color: #0a0a23;
  transform: scale(1.08);
}
    .results-section h2 {
      margin-top: 30px;
      font-size: 1.8em;
    }
    .food-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 25px;
      margin-top: 30px;
    }
    .food-card {
      background: #252a38;
      border-radius: 20px 5px 20px 5px;
      border: 1px solid #fd0a0a;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      transition: transform 0.3s ease;
    }
    .food-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.3);
    }
    .food-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }
    .food-card:hover img {
      transform: scale(1.05);
    }
    .food-info {
      padding: 15px;
    }
    .food-info h3 {
      margin: 0;
      font-size: 1.2em;
      color :rgb(255, 190, 12)
    }
    .food-info p {
      font-size: 0.95em;
      margin: 10px 0;
      color:rgb(208, 208, 208);
    }
    .food-benefits h4 {
      margin: 0 0 10px 0;
      font-size: 1em;
      color: #4ECDC4;
    }
    .btn {
      display: inline-block;
      background: #ff9f43;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      transition: background 0.3s ease;
    }
    .btn:hover {
      background: #ff6b3c;
    }
    .no-results,
    .welcome-section {
      text-align: center;
      padding: 40px 0;
      font-size: 1.1em;
      color: #ccc;
    }


.food-actions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 8px;
  align-items: stretch;
}

.food-actions button {
  background: linear-gradient(135deg,rgb(250, 6, 42),rgb(255, 12, 32));
  color: white;
  border: none;
  padding: 12px 18px;
  border-radius: 999px;
  font-size: 14px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.food-actions button:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.3);
  background: linear-gradient(135deg, #ff4757, #ff6b81);
}

.food-actions button:active {
  transform: scale(0.97);
}

.quick-save-btn {
  background: linear-gradient(135deg, #ff6b81, #ff4757);
  color: white;
  border: none;
  padding: 12px 18px;
  border-radius: 999px;
  font-size: 14px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%; /* <-- ini penting agar lebarnya sama */
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.quick-save-btn:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.3);
  background: linear-gradient(135deg, #ff4757, #ff6b81);
}


.food-actions button:focus {
  outline: none;
}

footer {
      background: #1A1A2E;
      color: #ccc;
      text-align: center;
      padding: 30px 0;
      margin-top: 80px;
    }
    
    .social-links {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin: 20px 0;
    }
    
    .social-links a {
      color: white;
      font-size: 1.5em;
      transition: all 0.3s ease;
    }
    
    .social-links a:hover {
      color: var(--primary);
      transform: translateY(-3px);
    }
  </style>
</head>
<body>
  <header>
    <div class="container">
      <h1>Food Mood</h1>
      <p>Temukan makanan yang cocok dengan perasaanmu hari ini</p>
    </div>
  </header>

  <div class="container">
    <form method="GET" action="">
      <div class="search-box">
        <input
          type="text"
          name="mood"
          placeholder="Apa mood kamu hari ini? (happy, sad, tired...)"
          value="<?= htmlspecialchars($mood) ?>"
          required
        />
        <button type="submit">Cari</button>
      </div>

  <div class="mood-tags">
    <?php foreach ($allMoods as $m): ?>
    <button
      type="button"
      class="mood-tag"
      onclick="document.querySelector('input[name=\'mood\']').value='<?= $m['nama_mood'] ?>'; this.form.submit()"
    >
      <?= $m['emoji'] ?> <?= ucfirst($m['nama_mood']) ?>
    </button>
    <?php endforeach; ?>
  </div>
</form>

<?php if ($mood): ?>
<section class="results-section">
  <?php if ($moodData): ?>
  <h2><?= $moodData['emoji'] ?> Rekomendasi untuk mood <?= $moodData['nama_mood'] ?></h2>
  <p><?= $moodData['deskripsi'] ?></p>
  <?php else: ?>
  <h2>Hasil untuk: <?= htmlspecialchars($mood) ?></h2>
  <?php endif; ?>

  <?php if (count($foodResults) > 0): ?>

  <div class="food-grid">
    <?php foreach ($foodResults as $food): ?>
      <div class="food-card" onclick="openFoodModal(
        '<?= addslashes($food['nama_makanan']) ?>',
        '<?= $food['gambar'] ?>',
        '<?= addslashes($food['deskripsi']) ?>',
        '<?= $food['mood'] ?? 'umum' ?>'
      )">
        <img src="<?= $food['gambar'] ?>" alt="<?= $food['nama_makanan'] ?>" />
        <div class="food-info">
          <h3><?= $food['nama_makanan'] ?></h3>
          <p><?= $food['deskripsi'] ?></p>
        </div>

    <div class="food-actions" onclick="event.stopPropagation();">


  <button onclick="window.open('https://www.youtube.com/results?search_query=<?= urlencode($food['nama_makanan']) ?> recipe', '_blank')">
    🔍 Tutorial
  </button>

  <button onclick="window.open('https://www.google.com/search?q=<?= urlencode($food['nama_makanan']) ?> delivery', '_blank')">
    🛒 Delivery
  </button>
</div>
</div>
<?php endforeach; ?>
  </div>


  <?php else: ?>
  <div class="no-results">
    <h3>Tidak ada hasil ditemukan</h3>
    <p>Coba cari dengan kata kunci lain</p>
  </div>
  <?php endif; ?>
</section>
<?php else: ?>
<section class="welcome-section">
  <h2>Selamat datang di Food Mood!</h2>
  <p>
    Pilih mood kamu atau ketikkan perasaanmu saat ini untuk mendapatkan
    rekomendasi makanan yang cocok.
  </p>
</section>
<?php endif; ?>
  </div>

  <footer>
    <div class="container">
      <h3>Food Mood</h3>
      <p>Makanan untuk setiap perasaan</p>
      <div class="social-links">
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-tiktok"></i></a>
        <a href="logout.php">Logout</a>
      </div>
      <p>&copy; 2023 Food Mood. All rights reserved.</p>
    </div>
  </footer>


  <script>
    const placeholders = [
      'Apa mood kamu hari ini? (happy, sad, tired...)',
      'Contoh: senang, marah, lelah...',
      'Cari makanan sesuai perasaanmu',
    ];
    let current = 0;

    setInterval(() => {
      document.querySelector('input[name="mood"]').placeholder =
        placeholders[current];
      current = (current + 1) % placeholders.length;
    }, 3000);

    function saveFavorite(foodName) {
  let favorites = JSON.parse(localStorage.getItem('foodMoodFavorites')) || [];
  if (!favorites.includes(foodName)) {
    favorites.push(foodName);
    localStorage.setItem('foodMoodFavorites', JSON.stringify(favorites));
    alert(`${foodName} disimpan ke favorit!`);
  } else {
    alert(`${foodName} sudah ada di favorit!`);
  }
}
</script>
</body>
</html>
