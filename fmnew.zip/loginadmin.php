<?php
// BARIS PALING ATAS
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "belajar_login";

    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Pastikan nama tabel benar (admin atau adminn?)
    $sql = "SELECT * FROM adminn WHERE email=?"; // Ganti ke nama tabel yang benar
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die("Error prepare: " . $conn->error);
    }
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['email'] = $user['email'];
            $_SESSION['logged_in'] = true;
            
            // Debugging - tampilkan data session sebelum redirect
            echo "<pre>Session data: ";
            print_r($_SESSION);
            echo "</pre>";
            
            // Pastikan path benar
            header("Location: /fmnew/rek.php"); // atau ./rek.php atau /path/rek.php
            exit;
        } else {
            $message = "Password salah!";
        }
    } else {
        $message = "Email tidak ditemukan!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
    <style>
        /* CSS tetap sama */
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <span>Sign In</span>

            <?php if (!empty($message)): ?>
                <p style="color: red;"><?php echo $message; ?></p>
            <?php endif; ?>

             <form id="login-form" action="loginadmin.php" method="POST">
        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" placeholder="hello@gmail.com" required>
        </div>

        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" placeholder="••••••••" required>
        </div>

        <button type="submit" class="sign-in-btn" id="login-btn">Sign In</button>
      </form>
        </div>
    </div>
</body>
</html>