<?php
require 'config.php';

$id = $_GET['id'];

// Ambil data mood
$query = "SELECT * FROM mood WHERE id_mood = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$mood = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $emoji = $_POST['emoji'];
    $deskripsi = $_POST['deskripsi'];
    $warna = $_POST['warna'];
    $kata_kunci = $_POST['kata_kunci'];

    $updateQuery = "UPDATE mood SET nama_mood=?, emoji=?, deskripsi=?, warna=?, kata_kunci=? WHERE id_mood=?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "sssssi", $nama, $emoji, $deskripsi, $warna, $kata_kunci, $id);
    mysqli_stmt_execute($stmt);

    header("Location: mood_read.php");
    exit;
}
?>

<h2>Edit Mood</h2>
<form method="post">
    Nama Mood: <input type="text" name="nama" value="<?= $mood['nama_mood'] ?>" required><br>
    Emoji: <input type="text" name="emoji" value="<?= $mood['emoji'] ?>" required><br>
    Deskripsi: <textarea name="deskripsi"><?= $mood['deskripsi'] ?></textarea><br>
    Warna: <input type="text" name="warna" value="<?= $mood['warna'] ?>" required><br>
    Kata Kunci: <input type="text" name="kata_kunci" value="<?= $mood['kata_kunci'] ?>" required><br>
    <button type="submit">Update</button>
</form>
