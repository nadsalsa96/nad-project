<?php
require_once 'config.php';  // koneksi database, $conn

// 1) Ambil daftar mood untuk checkbox
$result = mysqli_query($conn, "SELECT * FROM mood");
$moods = [];
while ($row = mysqli_fetch_assoc($result)) {
    $moods[] = $row;
}

// 2) Proses form
if (isset($_POST['submit'])) {
    $nama   = trim($_POST['nama_makanan']);
    $desc   = trim($_POST['deskripsi']);
    $img    = trim($_POST['gambar']);      // misal URL atau path
    $chosen = $_POST['moods'] ?? [];       // array of id_mood

    // 3) Masukkan ke table food (pakai prepared statement)
    $stmt = mysqli_prepare($conn, "INSERT INTO food (nama_makanan, deskripsi, gambar) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sss", $nama, $desc, $img);
    mysqli_stmt_execute($stmt);
    $newFoodId = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    // 4) Masukkan ke pivot table mood_food
    $stmt2 = mysqli_prepare($conn, "INSERT INTO mood_food (id_mood, id_food) VALUES (?, ?)");
    foreach ($chosen as $mid) {
        $mid = (int)$mid;
        mysqli_stmt_bind_param($stmt2, "ii", $mid, $newFoodId);
        mysqli_stmt_execute($stmt2);
    }
    mysqli_stmt_close($stmt2);

    echo "<p style='color:green;'>Makanan berhasil ditambahkan.</p>";
}
?>


<form method="POST">
  <label>Nama Makanan:</label><br>
  <input name="nama_makanan" required><br><br>

  <label>Deskripsi:</label><br>
  <textarea name="deskripsi" required></textarea><br><br>

  <label>URL Gambar:</label><br>
  <input name="gambar" required><br><br>

  <label>Pilih Mood (boleh lebih dari satu):</label><br>
  <?php foreach($moods as $m): ?>
    <input type="checkbox" name="moods[]" value="<?= $m['id_mood'] ?>">
      <?= htmlspecialchars($m['emoji'] . ' ' . $m['nama_mood']) ?><br>
  <?php endforeach; ?>
  <br>

  <button name="submit">Tambah Makanan</button>
</form>
