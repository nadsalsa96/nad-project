<?php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $emoji = $_POST['emoji'];
    $deskripsi = $_POST['deskripsi'];
    $warna = $_POST['warna'];
    $kata_kunci = $_POST['kata_kunci'];

    $stmt = $pdo->prepare("INSERT INTO mood (nama_mood, emoji, deskripsi, warna, kata_kunci) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$nama, $emoji, $deskripsi, $warna, $kata_kunci]);
    header("Location: mood_read.php");
}
?>

<h2>Tambah Mood</h2>
<form method="post">
    Nama Mood: <input type="text" name="nama" required><br>
    Emoji: <input type="text" name="emoji" required><br>
    Deskripsi: <textarea name="deskripsi" required></textarea><br>
    Warna: <input type="text" name="warna" required><br>
    Kata Kunci (pisahkan koma): <input type="text" name="kata_kunci" required><br>
    <button type="submit">Simpan</button>
</form>
