<?php
require_once 'config.php';
if (isset($_GET['id'])) {
  $id = (int)$_GET['id'];
  // 1) Hapus pivot terlebih dahulu
  $pdo->prepare("DELETE FROM mood_food WHERE id_food=?")->execute([$id]);
  // 2) Hapus food
  $pdo->prepare("DELETE FROM food WHERE id_food=?")->execute([$id]);
}
header("Location: lihat_makanan.php");
